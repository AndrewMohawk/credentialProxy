import { DashboardShell } from "@/components/dashboard-shell"
import { DashboardHeader } from "@/components/dashboard-header"
import { CredentialsTable } from "@/components/credentials-table"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"
import Link from "next/link"

export default function CredentialsPage() {
  return (
    <DashboardShell>
      <DashboardHeader heading="Credentials" text="Manage your secure credentials.">
        <Button asChild>
          <Link href="/credentials/new">
            <Plus className="mr-2 h-4 w-4" />
            Add Credential
          </Link>
        </Button>
      </DashboardHeader>
      <CredentialsTable />
    </DashboardShell>
  )
}

